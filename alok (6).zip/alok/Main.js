function ubahWarna() {
  document.body.style.backgroundColor = "#d1e7dd";
  alert("Warna latar belakang berubah!");
}

// Fungsi tambahan: tampilkan waktu sekarang
function tampilkanWaktu() {
  const sekarang = new Date();
  const waktu = sekarang.toLocaleTimeString();
  document.getElementById("waktu").textContent = "Sekarang pukul: " + waktu;
}

// Fungsi tambahan: ubah teks paragraf
function ubahTeks() {
  document.getElementById("pesan").textContent = "Kamu luar biasa! Tetap semangat!";
}